package usa.sesion15.reto3_grupo35.Vista;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import org.osmdroid.config.Configuration;
import org.osmdroid.library.BuildConfig;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.ItemizedIconOverlay;
import org.osmdroid.views.overlay.ItemizedOverlayWithFocus;
import org.osmdroid.views.overlay.OverlayItem;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.util.ArrayList;

import usa.sesion15.reto3_grupo35.Contolador.MainActivity;
import usa.sesion15.reto3_grupo35.Modelo.Adaptador;
import usa.sesion15.reto3_grupo35.Modelo.Entidad;
import usa.sesion15.reto3_grupo35.R;


public class Fragment_Sucursales extends Fragment {


    View v;

    ListView listaSucursales;
    Adaptador adaptador;

    //ADICIONAL AL Reto 4
    private MapView myOpenMapView;
    private MapController myMapController;

    GeoPoint Principal, Centro, Sur;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment__sucursales, container, false);
        //-----------------------------------------------------------------------------
        listaSucursales = (ListView) v.findViewById(R.id.lista_sucursales);
        adaptador = new Adaptador(GetArrayItems(), getContext());

        listaSucursales.setAdapter(adaptador);

        return v;
    }

    private ArrayList<Entidad> GetArrayItems(){
        ArrayList<Entidad> listaItems = new ArrayList<Entidad>();
        listaItems.add(new Entidad(R.drawable.sucursalp, "Principal", "Sucursal principal de Ipiales"));
        listaItems.add(new Entidad(R.drawable.sucursal1, "Centro", "Sucursal centro de Ipiales"));
        listaItems.add(new Entidad(R.drawable.sucursalsur, "Sur", "Sucursal sur de Ipiales"));
        return listaItems;
    }
}