package usa.sesion15.reto3_grupo35.Vista;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.ItemizedIconOverlay;
import org.osmdroid.views.overlay.ItemizedOverlayWithFocus;
import org.osmdroid.views.overlay.OverlayItem;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.util.ArrayList;

import usa.sesion15.reto3_grupo35.Modelo.Adaptador;
import usa.sesion15.reto3_grupo35.Modelo.Entidad;
import usa.sesion15.reto3_grupo35.R;


public class Fragment_Ubicacion extends Fragment {


    View v;

    //ADICIONAL AL Reto 4
    private MapView myOpenMapView;
    private MapController myMapController;

    GeoPoint Principal, Centro, Sur;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment__ubicacion, container, false);
        //-----------------------------------------------------------------------------


        //MAPA RETO 4
        myOpenMapView = (MapView) v.findViewById(R.id.openmapview);
        /*   punto de geolocalizacion del reto4 */
        Principal = new GeoPoint(0.8334452966920848, -77.65450014692166);
        Centro = new GeoPoint(0.8261310195972227, -77.63890502463562);
        Sur = new GeoPoint(0.8146970501655512, -77.66287141010592);

        myOpenMapView.setBuiltInZoomControls(true);

        myMapController = (MapController) myOpenMapView.getController();
        myMapController.setCenter(Principal);
        myMapController.setZoom(12);

        myOpenMapView.setMultiTouchControls(true);

        //-----------------------------------------------------------------------------

        /* -------------------------------------------------------------------------------------------------- */
        final MyLocationNewOverlay myLocationoverlay = new MyLocationNewOverlay(new GpsMyLocationProvider(getContext()), myOpenMapView);
        myOpenMapView.getOverlays().add(myLocationoverlay); //No añadir si no quieres una marca
        myLocationoverlay.enableMyLocation();

        myLocationoverlay.runOnFirstFix(new Runnable() {
            public void run() {
                myMapController.animateTo(myLocationoverlay.getMyLocation());
            }
        });
        /* -------------------------------------------------------------------------------------------------- */

        /* MARCAS EN EL MAPA */

        ArrayList<OverlayItem> puntos = new ArrayList<OverlayItem>();
        puntos.add(new OverlayItem("Tienda Principal", "Principal Ipiales", Principal));
        puntos.add(new OverlayItem("Centro", "Tienda Centro", Centro));
        puntos.add(new OverlayItem("Sur", "Tienda Sur", Sur));

        ItemizedIconOverlay.OnItemGestureListener<OverlayItem> tap = new ItemizedIconOverlay.OnItemGestureListener<OverlayItem>() {
            @Override
            public boolean onItemLongPress(int arg0, OverlayItem arg1) {
                return false;
            }
            @Override
            public boolean onItemSingleTapUp(int index, OverlayItem item) {
                return true;
            }
        };

        ItemizedOverlayWithFocus<OverlayItem> capa = new ItemizedOverlayWithFocus<OverlayItem>(getContext(), puntos, tap);
        capa.setFocusItemsOnTap(true);
        myOpenMapView.getOverlays().add(capa);

        return v;
    }

}